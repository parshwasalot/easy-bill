export interface BillRequest {
  billId: string;
  urlHash: string;
  amount: number;
  date: string;
  customerName: string;
  phone: string;
} 