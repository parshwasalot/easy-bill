export const COLORS = {
    primary: '#6200ee',
    secondary: '#03dac4',
    white: '#FFFFFF',
    black: '#000000',
    gray: '#757575',
    lightGray: '#F5F5F5',
    error: '#B00020',
    success: '#4CAF50',
    warning: '#FFC107',
  };