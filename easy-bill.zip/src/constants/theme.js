export const typography = {
  headingSmall: {
    fontSize: 16,
    fontWeight: '600',
  },
  headingMedium: {
    fontSize: 18,
    fontWeight: '700',
  },
  // ... rest of typography
}; 