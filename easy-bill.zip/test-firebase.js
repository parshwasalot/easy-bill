"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Firebase auth/native import works');
